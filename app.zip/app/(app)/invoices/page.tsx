"use client";

import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { createPortal } from "react-dom";
import styles from "./Invoices.module.css";
import { useAllPayments } from "@/services/invoices/invoices.hooks";
import { PaymentRecord } from "@/services/invoices/invoices.api";
import InvoiceGeneratorModal from "./InvoiceGeneratorModal";
import {useInvoiceGenerator} from "@/services/invoices/invoice-generator.hook";

const fadeUp = {
  hidden:  { opacity: 0, y: 14 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.4, delay: i * 0.07, ease: [0.16, 1, 0.3, 1] as any },
  }),
};

function getMember(payment: PaymentRecord) {
  if (payment.memberId && typeof payment.memberId === "object") return payment.memberId;
  return null;
}

export default function InvoicesPage() {
  const { data: payments, isLoading, isError } = useAllPayments();

  const [search, setSearch] = useState("");
  const [selectedPayment, setSelectedPayment] = useState<PaymentRecord | null>(null);
  const [mounted, setMounted] = useState(false);

  const { isOpen, invoiceData, openFromPayment, close } = useInvoiceGenerator();

  useEffect(() => { setMounted(true); }, []);

  const paymentsArray = Array.isArray(payments) ? payments : [];

  const total         = paymentsArray.length;
  const totalAmount   = paymentsArray.reduce((sum, p) => sum + (p.amount   || 0), 0);
  const totalReceived = paymentsArray.reduce((sum, p) => sum + (p.received || 0), 0);
  const totalPending  = paymentsArray.reduce((sum, p) => sum + (p.pending  || 0), 0);

  const filtered = useMemo(() => {
    if (!paymentsArray.length) return [];
    const q = search.toLowerCase();
    return paymentsArray.filter(payment => {
      const member = getMember(payment);
      return !q ||
        payment.transactionId?.toLowerCase().includes(q) ||
        member?.name.toLowerCase().includes(q) ||
        (member?.phone ?? "").includes(q);
    });
  }, [paymentsArray, search]);

  const STATS = [
    { label: "Total Payments", val: String(total),                        sub: "all time"   },
    { label: "Total Amount",   val: `₹${totalAmount.toLocaleString()}`,   sub: "billed"     },
    { label: "Total Received", val: `₹${totalReceived.toLocaleString()}`, sub: "collected"  },
    { label: "Total Pending",  val: `₹${totalPending.toLocaleString()}`,  sub: "outstanding"},
  ];

  return (
    <div className={styles.page}>

      <motion.div className={styles.pageHeader}
        initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as any }}
      >
        <div>
          <p className={styles.eyebrow}>Admin Panel</p>
          <h1 className={styles.pageTitle}>Payments</h1>
          <p className={styles.pageDesc}>Track all member payments and outstanding balances.</p>
        </div>
      </motion.div>

      <motion.div className={styles.statStrip} custom={0} variants={fadeUp} initial="hidden" animate="visible">
        {STATS.map((st) => (
          <div key={st.label} className={styles.statCell}>
            <span className={styles.statLabel}><span className={styles.statLabelDot} />{st.label}</span>
            <span className={styles.statVal}>{st.val}</span>
            <span className={styles.statSub}>{st.sub}</span>
          </div>
        ))}
      </motion.div>

      <motion.div className={styles.card} custom={1} variants={fadeUp} initial="hidden" animate="visible">
        <div className={styles.cardHeader}>
          <h2 className={styles.cardTitle}><span className={styles.cardTitleBar} />All Payments</h2>
          <div className={styles.toolbar}>
            <div className={styles.searchWrap}>
              <span className={styles.searchIcon}>⌕</span>
              <input
                className={styles.searchInput}
                placeholder="Search payment or member…"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className={styles.tableWrap}>
          {isLoading && <p style={{ padding: "1rem", color: "#555" }}>Loading payments…</p>}
          {isError   && <p style={{ padding: "1rem", color: "#e63946" }}>Failed to load payments.</p>}

          {!isLoading && !isError && (
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Transaction ID</th>
                  <th>Member</th>
                  <th>Amount</th>
                  <th>Received</th>
                  <th>Pending</th>
                  <th>Method</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} style={{ padding: "2rem", textAlign: "center", color: "#444" }}>
                      {paymentsArray.length === 0 ? "No payments found." : "No payments match your search."}
                    </td>
                  </tr>
                )}
                {filtered.map((payment) => {
                  const member = getMember(payment);
                  return (
                    <tr key={payment._id}>
                      <td className={styles.cellId}>{payment.transactionId ?? "—"}</td>
                      <td>
                        <div className={styles.cellName}>{member?.name ?? "—"}</div>
                        <div className={styles.cellEmail}>{member?.phone ?? "—"}</div>
                      </td>
                      <td className={styles.cellAmount}>₹{payment.amount.toLocaleString()}</td>
                      <td className={styles.cellAmount}>₹{payment.received.toLocaleString()}</td>
                      <td className={styles.cellAmount}>₹{payment.pending.toLocaleString()}</td>
                      <td style={{ textTransform: "uppercase", fontSize: "0.82rem" }}>{payment.mop}</td>
                      <td className={styles.cellMono}>
                        {new Date(payment.paymentDate).toLocaleDateString()}
                      </td>
                      <td>
                        <div className={styles.rowActions}>
                          {/* View details */}
                          <button
                            className={styles.iconBtn}
                            title="View Details"
                            onClick={() => setSelectedPayment(payment)}
                          >👁</button>
                          {/* Generate invoice directly from this row */}
                          <button
                            className={styles.iconBtn}
                            title="Generate Invoice"
                            onClick={() => openFromPayment(payment)}
                          >📄</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <div className={styles.pagination}>
          <span className={styles.paginationInfo}>
            {filtered.length !== paymentsArray.length
              ? `Showing ${filtered.length} of ${paymentsArray.length} payments`
              : `${paymentsArray.length} payment${paymentsArray.length !== 1 ? "s" : ""}`}
          </span>
          <div className={styles.paginationBtns}>
            <button className={styles.pageBtn} disabled>‹</button>
            <button className={`${styles.pageBtn} ${styles.pageBtnActive}`}>1</button>
            <button className={styles.pageBtn} disabled>›</button>
          </div>
        </div>
      </motion.div>

      {/* Payment detail modal */}
      {mounted && selectedPayment && createPortal(
        <AnimatePresence>
          {selectedPayment && (
            <>
              <motion.div
                className={styles.backdrop}
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setSelectedPayment(null)}
              />
              <motion.div
                className={styles.invoiceViewModal}
                initial={{ opacity: 0, y: 24, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 16, scale: 0.97 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as any }}
              >
                <div className={styles.invoiceViewHeader}>
                  <h2 className={styles.invoiceViewTitle}>Payment Details</h2>
                  <button className={styles.closeBtn} onClick={() => setSelectedPayment(null)}>✕</button>
                </div>
                <div className={styles.invoiceViewContent}>
                  <div className={styles.paymentDetails}>
                    <div className={styles.paymentHeader}>
                      <h3 className={styles.paymentTitle}>Payment Details</h3>
                      <div className={styles.paymentStatus}>
                        <span className={`${styles.statusBadge} ${selectedPayment.pending > 0 ? styles.statusPartial : styles.statusComplete}`}>
                          {selectedPayment.pending > 0 ? "Partial" : "Complete"}
                        </span>
                      </div>
                    </div>

                    <div className={styles.paymentGrid}>
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Payment Method</span>
                        <span className={styles.detailValue}>{selectedPayment.mop.toUpperCase()}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Payment Date</span>
                        <span className={styles.detailValue}>{new Date(selectedPayment.paymentDate).toLocaleDateString()}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Total Amount</span>
                        <span className={styles.detailValue}>₹{selectedPayment.amount.toLocaleString()}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Amount Received</span>
                        <span className={`${styles.detailValue} ${styles.amountReceived}`}>₹{selectedPayment.received.toLocaleString()}</span>
                      </div>
                      <div className={styles.detailRow}>
                        <span className={styles.detailLabel}>Pending Amount</span>
                        <span className={`${styles.detailValue} ${selectedPayment.pending > 0 ? styles.amountPending : styles.amountZero}`}>
                          ₹{selectedPayment.pending.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {selectedPayment.notes && (
                      <div className={styles.notesSection}>
                        <h4 className={styles.notesTitle}>Notes</h4>
                        <p className={styles.notesText}>{selectedPayment.notes}</p>
                      </div>
                    )}

                    {/* Generate invoice from the detail modal too */}
                    <div style={{ marginTop: "1.5rem", display: "flex", justifyContent: "flex-end" }}>
                      <button
                        className={styles.btnPrimary}
                        onClick={() => {
                          openFromPayment(selectedPayment);
                          setSelectedPayment(null);
                        }}
                      >
                        📄 Generate Invoice
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>,
        document.body
      )}

      {/* Invoice generator modal */}
      {mounted && createPortal(
        <InvoiceGeneratorModal
          open={isOpen}
          onClose={close}
          invoiceData={invoiceData}
        />,
        document.body
      )}
    </div>
  );
}
import {
  AxiosError,
  AxiosResponse,
  InternalAxiosRequestConfig,
} from "axios";
import apiClient from "./apiClient";
import { authStorage } from "./storage/authStorage";

// 🔹 Request Interceptor
const requestInterceptor = (
  config: InternalAxiosRequestConfig
): InternalAxiosRequestConfig => {
  const token = authStorage.getToken();

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
};

// 🔹 Response Interceptor
const responseInterceptor = (
  response: AxiosResponse
): AxiosResponse => response;

const errorInterceptor = (error: AxiosError): Promise<never> => {
  if (error.response?.status === 401) {
    authStorage.clearToken();
    window.location.href = "/login";
  }

  return Promise.reject(error);
};

// 🔥 Register Interceptors
apiClient.interceptors.request.use(requestInterceptor, (error) =>
  Promise.reject(error)
);

apiClient.interceptors.response.use(
  responseInterceptor,
  errorInterceptor
);
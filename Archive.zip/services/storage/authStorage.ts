import storageService from "./storageService";

const TOKEN_KEY = "sessionToken";

export const authStorage = {
  setToken: (token: string): void => {
    storageService.setItem<string>(TOKEN_KEY, token);
  },

  getToken: (): string | null => {
    return storageService.getItem<string>(TOKEN_KEY);
  },

  clearToken: (): void => {
    storageService.removeItem(TOKEN_KEY);
  },
};
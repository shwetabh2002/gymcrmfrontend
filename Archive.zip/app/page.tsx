"use client";

import { useEffect } from "react";
import apiClient from "@/services/apiClient";

export default function HomePage() {
  useEffect(() => {
    apiClient.get("/test")
      .then((res) => console.log("Response:", res))
      .catch((err) => console.log("Error:", err));
  }, []);

  return <div>Welcome to Gym Admin</div>;
}